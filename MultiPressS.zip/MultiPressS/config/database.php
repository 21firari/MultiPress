// config/database.php
<?php
return [
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'admin_multipress_hub',
    'username' => 'root_hub',
    'password' => 'l6?x87T0h',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => 'mph_'
];